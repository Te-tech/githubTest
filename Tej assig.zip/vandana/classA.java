package com.nt.pack;

import java.util.Scanner;

public class classA {

	public static void main(String[] args) {
		Scanner  sc = new Scanner(System.in);
		System.out.print("enter a sentence");
		String str = sc.nextLine();
		System.out.print("enter a character");
		String c = sc.nextLine();
		int position = str.indexOf(c);
		if(position==-1) {
			System.out.print("the letter does not exist in the sentence");
		}
		if(position==0) {
			if(c.isEmpty()) {
				System.out.print(str);
				}
			else {
				String result=str.substring(position+1);
				System.out.print(result);
				}
		}
		if(position!=-1&&position!=0) {
			String resultt=str.substring(position+1);
			System.out.print(resultt);
		}
		

	}
}
